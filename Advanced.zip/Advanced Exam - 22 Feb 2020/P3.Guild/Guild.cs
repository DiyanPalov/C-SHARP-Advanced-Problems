﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Guild
{
   public class Guild
    {
        private  List<Player> roster;

        private Guild()
        {
            this.roster = new List<Player>();
        }
        public Guild(string name,int capacity):this()
        {
            this.Name = name;
            this.Capacity = capacity;
        }
        public string Name { get; set; }
        public int Capacity { get; set; }

        public int Count => roster.Count;

        public void AddPlayer(Player player) 
        {
            if (this.roster.Count<Capacity)
            {
                this.roster.Add(player);
            }
        }

        public bool RemovePlayer(string name) 
        {
            Player player = this.roster.FirstOrDefault(n => n.Name == name); // n.Name !!!!!
            if (this.roster.Contains(player)&&player!=null)
            {
                this.roster.Remove(player);
                return true;
            }

            return false;
        }

        public void PromotePlayer(string name)
        {
            Player player = this.roster.FirstOrDefault(n => n.Name == name);
            if (player!=null)
            {
            player.Rank = "Member";

            }

            //if (roster.Find(x => x.Name == name) == null || roster.Find(x => x.Name == name).Rank == "Member")
            //    return;
            //else
            //{
            //    roster.Find(x => x.Name == name).Rank = "Member";
            //}
        }
        public void DemotePlayer(string name)
        {
            Player player = this.roster.FirstOrDefault(n => n.Name == name);
            if (player != null)
            {
                player.Rank = "Trial";

            }
        }

        public Player[] KickPlayersByClass(string clas)
        {
            Player[] arrTemp;
            arrTemp = this.roster.Where(c => c.Class == clas).ToArray();

            roster = roster.Where(x => x.Class != clas).ToList();

            return arrTemp;
           
        } 
        public string Report()
        {
            StringBuilder myString = new StringBuilder();
            myString.AppendLine($"Players in the guild: {this.Name}");
            foreach (var player in this.roster)
            {
                myString.AppendLine($"Player {player.Name}: {player.Class}");
                myString.AppendLine($"Rank: {player.Rank}");
                myString.AppendLine($"Description: {player.Description}");
            }
            return myString.ToString().TrimEnd();
        }
    }
}
