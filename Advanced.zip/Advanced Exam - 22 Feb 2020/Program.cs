﻿using System;

namespace Advanced_Exam___22_Feb_2020
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
