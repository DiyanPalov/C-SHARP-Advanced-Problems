﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P1._Dating_App
{
    class Program
    {
        static void Main(string[] args)
        {
            //////100/100 //////////////////////
            Stack<int> males = new Stack<int>(Console.ReadLine().Split().Select(int.Parse));
            Queue<int> females = new Queue<int>(Console.ReadLine().Split().Select(int.Parse));
            int matching = 0;
            while (males.Any() && females.Any())
            {

                int currentMales = males.Peek();
                int currentFemales = females.Peek();

                if (currentFemales <= 0)//proverka za 0 - clear
                {
                    females.Dequeue();
                    continue;

                }
                if (currentMales <= 0)// proverka za 0 - clear
                {
                    males.Pop();
                    continue;
                }
                if (currentMales % 25 == 0)//proverka za "Special case"
                {
                    males.Pop();
                    males.Pop();
                    continue;
                }
                if (currentFemales % 25 == 0)//proverka za "Special case" - ot uslovieto
                {
                    females.Dequeue();
                    females.Dequeue();
                    continue;
                }

                if (currentMales == currentFemales)//proverka za el = el
                {
                    matching++;
                    males.Pop();
                    females.Dequeue();
                }
                else//ot uslovieto- "Otherwise you should remove only the female and decrease the value of the male by 2."
                {
                    females.Dequeue();
                    males.Push(males.Pop() - 2);
                }

            }
            /////PRINT LINE 1/////////////////
            Console.WriteLine($"Matches: {matching}");
            /////line 2//////////////
            if (males.Any())
            {
                Console.WriteLine($"Males left: {string.Join(", ", males)}");
            }
            else
            {
                Console.WriteLine("Males left: none");
            }
            //////// PRINT line 3 /////////////////////
            if (females.Any())
            {
                Console.WriteLine($"Females left: " + string.Join(", ", females));
            }
            else
            {
                Console.WriteLine("Females left: none");
            }


        }
    }
}