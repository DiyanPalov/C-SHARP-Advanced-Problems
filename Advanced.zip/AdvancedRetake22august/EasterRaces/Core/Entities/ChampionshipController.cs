﻿using EasterRaces.Core.Contracts;
using EasterRaces.Models.Cars.Contracts;
using EasterRaces.Models.Cars.Entities;
using EasterRaces.Models.Drivers.Contracts;
using EasterRaces.Models.Drivers.Entities;
using EasterRaces.Models.Races.Contracts;
using EasterRaces.Models.Races.Entities;
using EasterRaces.Repositories.Entities;
using EasterRaces.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EasterRaces.Core.Entities
{
    public class ChampionshipController : IChampionshipController
    {
        private CarRepository cars;
        private DriverRepository drivers;
        private RaceRepository races;

        public ChampionshipController()
        {
            this.cars = new CarRepository();
            this.drivers = new DriverRepository();
            this.races = new RaceRepository();
        }

        public string AddCarToDriver(string driverName, string carModel)
        {
            if (!this.drivers.GetAll().Any(d=>d.Name ==driverName))
            {
                throw new InvalidOperationException($"Driver {driverName} could not be found.");
            }
            if (!this.cars.GetAll().Any(c => c.Model == carModel))
            {
                throw new InvalidOperationException($"Car {carModel} could not be found.");
            }
            ICar car = this.cars.GetAll().FirstOrDefault(n => n.Model == carModel);
         
            IDriver driver = this.drivers.GetAll().FirstOrDefault(d => d.Name == driverName);

            driver.AddCar(car);

            return $"Driver {driver.Name} received car {car.Model}.";
        }

        public string AddDriverToRace(string raceName, string driverName)
        {
            if (!this.races.GetAll().Any(r => r.Name == raceName))
            {
                throw new InvalidOperationException($"Race {raceName} could not be found.");
            }

            if (!this.drivers.GetAll().Any(d => d.Name == driverName))
            {
                throw new InvalidOperationException(string.Format($"Driver {driverName} could not be found."));
            }

            IRace race = this.races.GetAll().FirstOrDefault(r => r.Name == raceName);
            IDriver driver = this.drivers.GetAll().FirstOrDefault(d => d.Name == driverName);
            race.AddDriver(driver);

            return $"Driver {driverName} added in {raceName} race.";

        }

        public string CreateCar(string type, string model, int horsePower)
        {
            ICar car= null;

            if (this.cars.GetAll().Any(b=>b.Model== model))
            {
                throw new ArgumentException($"Car {model} is already created.");
            }

            if (type == "Muscle")
            {
                car = new MuscleCar(model, horsePower);
               
            }
            else if (type == "Sports")
            {
                car = new SportsCar(model, horsePower);
            }
            this.cars.Add(car);

            return $"{car.GetType().Name} {car.Model} is created.";
        }

        public string CreateDriver(string driverName)
        {
            if (this.drivers.GetAll().Any(d=>d.Name == driverName))
            {
                throw new ArgumentException($"Driver {driverName} is already created.");
            }
            this.drivers.Add(new Driver(driverName));

            return $"Driver {driverName} is created.";
        }

        public string CreateRace(string name, int laps)
        {
            if (this.races.GetAll().Any(r => r.Name == name))
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.RaceExists, name));
            }

            IRace race = new Race(name, laps);
            this.races.Add(race);

            string output = string.Format(OutputMessages.RaceCreated, name);

            return output;
        }

        public string StartRace(string raceName)
        {
            if (!this.races.GetAll().Any(r => r.Name == raceName))
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.RaceNotFound, raceName));
            }
            IRace race = this.races.GetAll().FirstOrDefault(r => r.Name == raceName);

            if (race.Drivers.Count < 3)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.RaceInvalid, raceName, 3));
            }

            List<IDriver> driversInRace = race.Drivers
                .ToList()
                .OrderByDescending(d => d.Car.CalculateRacePoints(race.Laps))
                .Take(3).ToList();

            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < driversInRace.Count; i++)
            {
                IDriver driver = driversInRace[i];
                if (i == 0)
                {
                    sb.AppendLine(string.Format(OutputMessages.DriverFirstPosition, driver.Name, raceName));
                }
                else if (i == 1)
                {
                    sb.AppendLine(string.Format(OutputMessages.DriverSecondPosition, driver.Name, raceName));
                }
                else if (i == 2)
                {
                    sb.AppendLine(string.Format(OutputMessages.DriverThirdPosition, driver.Name, raceName));
                }

            }
            this.races.Remove(race);
            return sb.ToString().Trim();
        }
    }
}
