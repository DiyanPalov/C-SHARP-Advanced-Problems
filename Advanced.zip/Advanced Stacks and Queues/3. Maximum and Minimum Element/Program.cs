﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
namespace _3._Maximum_and_Minimum_Element
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Stack<int> numbers = new Stack<int>();
            for (int i = 0; i < n; i++)
            {
                string command = Console.ReadLine();
                string[] tokens = command.Split(" ");

                if (tokens[0]=="1")
                {
                    numbers.Push(int.Parse(tokens[1]));
                }
                else if (tokens[0]=="2")
                {
                    if (numbers.Count>=1)
                    {

                    numbers.Pop();
                    }
                }
                else if (tokens[0]=="3")
                {
                    if (numbers.Count>=1)
                    {
                        Console.WriteLine(numbers.Max());
                    }
                }
                else if (tokens[0]=="4")
                {
                    if (numbers.Count >= 1)
                    {
                        Console.WriteLine(numbers.Min());
                    }
                }
            }
            
            Console.WriteLine(string.Join(", ",numbers));
        }
    }
}
