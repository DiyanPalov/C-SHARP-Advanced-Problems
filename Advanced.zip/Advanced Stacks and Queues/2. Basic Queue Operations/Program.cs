﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
namespace _2._Basic_Queue_Operations
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] n = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();
            Queue<int> stack = new Queue<int>();
            int[] number = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();

            for (int i = 0; i < n[0]; i++)
            {
                stack.Enqueue(number[i]);
            }
            for (int j = 0; j < n[1]; j++)
            {
                stack.Dequeue();
            }
            if (stack.Count >= 1)
            {
                if (stack.Contains(n[2]))
                {
                    Console.WriteLine("true");
                }
                else
                {
                    Console.WriteLine(stack.Min());
                }
            }
            else
            {
                Console.WriteLine(0);
            }

        }
    }
}
