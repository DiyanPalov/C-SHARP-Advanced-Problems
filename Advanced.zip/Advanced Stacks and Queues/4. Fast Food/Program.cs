﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
namespace _4._Fast_Food
{
    class Program
    {
        static void Main(string[] args)
        {
            int amountFood = int.Parse(Console.ReadLine());
            Queue<int> Orders = new Queue<int>();
            int[] orderamount = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();

            foreach (var item in orderamount)
            {
                Orders.Enqueue(item);
            }
            Console.WriteLine(Orders.Max());
            for (int i = 0; i < orderamount.Length; i++)
            {
                if (Orders.Peek() <= amountFood)
                {
                    amountFood -= Orders.Dequeue();
                    if (Orders.Count == 0)
                    {
                        break;
                    }
                }
                else
                {
                    break;
                }


            }
            if (Orders.Count==0)
            {
                Console.WriteLine("Orders complete");
            }
            else
            {
                Console.WriteLine($"Orders left: {(string.Join(" ",Orders))}");
            }
        }
    }
}
