﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
namespace _6._Songs_Queue
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> songs = Console.ReadLine().Split(", ").ToList();
            Queue<string> playing = new Queue<string>();
            for (int i = 0; i < songs.Count; i++)
            {
                playing.Enqueue(songs[i]);
            }
            string command = Console.ReadLine();

            while (playing.Count!=0)
            {
                string[] tokens = command.Split(" ");

                if (tokens[0]=="Play")
                {
                    playing.Dequeue();
                    if (playing.Count == 0)
                    {
                        Console.WriteLine("No more songs!"); //maybe change
                        break;
                    }
                }
                else if (tokens[0]=="Add")
                {
                    string song = command.Substring(4,command.Length-4);
                    if (!playing.Contains(song))
                    {
                        playing.Enqueue(song);
                    }
                    else
                    {
                        Console.WriteLine($"{song} is already contained!");
                    }
                }
                else if (tokens[0] == "Show")
                {
                    Console.WriteLine(string.Join(", ",playing));
                }
                command = Console.ReadLine();
            }
        }
    }
}
