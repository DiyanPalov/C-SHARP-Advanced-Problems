﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _1._Generic_Box_of_String
{
    public class Box<T> where T : IComparable
    {
        public List<T> list;
        public Box(List<T> value)
        {
            list = new List<T>();
            this.list = value;
            //  this.Values = value;
        }
        // public List<T> Values { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            foreach (var item in this.list)//Values
            {
                sb.AppendLine($"{item.GetType()}: {item}");
            }
           return sb.ToString().TrimEnd();

        }

        public void Swap(List<T> items, int firstindex, int secondindex)
        {
            T tempValue = items[firstindex];

            items[firstindex] = items[secondindex];

            items[secondindex] = tempValue;
        }

        public int Mymethod(List<T> items,T element)
        {
            int counter = 0; 
            foreach (var item in items)
            {
                if (element.CompareTo(item)<0)
                {
                    counter++;
                }
            }
            return counter;
        }
    }
}
