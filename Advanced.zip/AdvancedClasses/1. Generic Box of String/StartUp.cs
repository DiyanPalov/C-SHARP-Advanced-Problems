﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _1._Generic_Box_of_String
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<double> names = new List<double>();
           
            for (int i = 0; i < n; i++)
            {
                double message = double.Parse(Console.ReadLine());

                names.Add(message);  
            }
            double element =double.Parse( Console.ReadLine());
            Box<double> box = new Box<double>(names);

            // int[] swapIndex = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();
            //  box.Swap(names, swapIndex[0], swapIndex[1]);
            int result = box.Mymethod(names, element);
            Console.WriteLine(result);
        }
    }
}
