﻿using System;

namespace Tuples
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var person = Console.ReadLine().Split(" ");
            string personName = $"{person[0]} {person[1]}";
            string personAdress = $"{person[2]}";
            var nameAndBeer = Console.ReadLine().Split(" ");
            string name = $"{nameAndBeer[0]}";
            int beer = int.Parse(nameAndBeer[1]);
            var intAndDouble= Console.ReadLine().Split(" ");
            int intValeu = int.Parse(intAndDouble[0]);
            double doubleValue = double.Parse(intAndDouble[1]);

            Tuple<string, string> tuple = new Tuple<string, string>(personName, personAdress);
            Tuple<string, int> tuple1 = new Tuple<string, int>(name, beer);
            Tuple<int, double> tuple2 = new Tuple<int, double>(intValeu, doubleValue);

            Console.WriteLine(tuple);
            Console.WriteLine(tuple1);
            Console.WriteLine(tuple2);
        }
    }
}
