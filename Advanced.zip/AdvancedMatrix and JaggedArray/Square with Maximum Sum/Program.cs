﻿using System;

namespace Square_with_Maximum_Sum
{
    class Program
    {
        static void Main(string[] args)
        {
            //// TODO: Read the input from the console

            //for (int row = 0; row < matrix.GetLength(0) - 1; row++)
            //{

            //    for (int col = 0; col < matrix.GetLength(1) - 1; col++)
            //    {

            //        var newSquareSum = matrix[row, col] +

            //        matrix[row + 1, col] +

            //        matrix[row, col + 1] +

            //        matrix[row + 1, col + 1];

            //        // TODO: Check if the sum is bigger

            //    }

            //}

            //// TODO: Print the square with the max sum
        }
    }
}
