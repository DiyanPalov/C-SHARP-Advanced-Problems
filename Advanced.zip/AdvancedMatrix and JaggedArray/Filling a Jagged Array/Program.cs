﻿using System;

namespace Filling_a_Jagged_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] jagged = new int[5][];

            for (int row = 0; row < jagged.Length; row++)

            {

                string[] inputNumbers = Console.ReadLine().Split(' ');

                jagged[row] = new int[inputNumbers.Length];

                for (int col = 0; col < jagged[row].Length; col++)

                {

                    jagged[row][col] = int.Parse(inputNumbers[col]);

                }

            }
            //Printing а Jagged Array – Example
//            For - loop

//Foreach loop

//Printing а Jagged Array – Example

//            int[][] matrix = ReadMatrix();

//            for (int row = 0; row < matrix.Length; row++)

//                for (int col = 0; col < matrix[row].Length; col++)

//                    Console.Write("{0} ", matrix[row][col]);

//            Console.WriteLine();

//            int[][] matrix = ReadMatrix();

//            foreach (int[] row in matrix)

//            {

//                Console.WriteLine(string.Join(" ", row));

//            }
        }
    }
}
