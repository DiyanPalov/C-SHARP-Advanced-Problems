﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
namespace _1._Diagonal_Difference
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            long[,] matrix = new long[n, n];

            long primaryDiagonal = 0;
            long secondaryDiagonal = 0;

            for (int row = 0; row < n; row++)
            {
                int[] rowInts = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();

                for (int col = 0; col < n; col++)
                {
                    matrix[row, col] = rowInts[col];

                    if (row == col)
                    {
                        primaryDiagonal += rowInts[col];
                    }

                    if (col == ((n - 1) - row))
                    {
                        secondaryDiagonal += rowInts[col];
                    }
                }
            }

            Console.WriteLine(Math.Abs(primaryDiagonal - secondaryDiagonal));
        }
    }
}