﻿using System;
using System.Linq;
namespace _5._Snake_Moves
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] inputRowsColums = Console.ReadLine().Split().Select(int.Parse).ToArray();
            int rows = inputRowsColums[0];
            int colums = inputRowsColums[1];
            char[,] matrix = new char[rows, colums];
            string input = Console.ReadLine();
            //inputMatrix
            int indexSymbolString = 0;
            for (int row = 0; row < rows; row++)
            {
                if (row % 2 == 0)
                {
                    for (int col = 0; col < colums; col++)
                    {
                        if (indexSymbolString >= input.Length)
                        {
                            indexSymbolString = 0;
                        }

                        matrix[row, col] = input[indexSymbolString];
                        indexSymbolString++;
                    }
                }
                else
                {
                    for (int col = colums - 1; col >= 0; col--)
                    {
                        if (indexSymbolString >= input.Length)
                        {
                            indexSymbolString = 0;
                        }
                        matrix[row, col] = input[indexSymbolString];
                        indexSymbolString++;
                    }
                }
            }
            for (int row = 0; row < rows; row++)
            {
                for (int col = 0; col < colums; col++)
                {
                    Console.Write(matrix[row, col]);
                }

                Console.WriteLine();
            }

        }
    }
}