﻿using System;
using System.Linq;
namespace _4._Matrix_Shuffling
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] size = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();
            int rows = size[0];
            int cols = size[1];
            
            string[,] matrix = new string[rows, cols];

            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                string[] input = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();
                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    matrix[row, col] = input[col];
                }
            }
            string command = Console.ReadLine();
            while (command!="END")
            {
                string[] tokens = command.Split(" ");
                if (tokens[0]=="swap"&&tokens.Length==5)
                {
                    int rowsindex = int.Parse(tokens[1]);
                    int colsindex = int.Parse(tokens[2]);
                    int rowsindex2 = int.Parse(tokens[3]);
                    int colsindex2 = int.Parse(tokens[4]);

                    if (rowsindex>=0&& rowsindex<rows&&
                        colsindex>=0&& colsindex<cols&&
                        rowsindex2>=0&& rowsindex2<rows&&
                        colsindex2>=0&& colsindex2<cols)
                    {
                        string old = matrix[rowsindex, colsindex];
                        string neww = matrix[rowsindex2, colsindex2];
                        matrix[rowsindex, colsindex] = neww;
                        matrix[rowsindex2, colsindex2] = old;

                        for (int row = 0; row < matrix.GetLength(0); row++)
                        {
                           
                            for (int col = 0; col < matrix.GetLength(1); col++)
                            {
                                Console.Write(matrix[row,col]+ " ");
                            }
                            Console.WriteLine();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input!");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input!");
                }
                command = Console.ReadLine();
            }
        }
    }
}
