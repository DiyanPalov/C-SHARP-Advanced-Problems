﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace VetClinic
{
    public class Clinic
    {
        private  List<Pet> data;

        private Clinic()
        {
            this.data = new List<Pet>();
        }
        public Clinic(int capacity):this()
        {
            this.Capacity = capacity;
        }
        public int Capacity { get; set; }
        public int Count => this.data.Count;

        public void Add(Pet pet)
        {
            if (this.data.Count+1<=Capacity) //?
            {
                this.data.Add(pet);
            }
        }

        public bool Remove(string name)
            
        {
            Pet pet = this.data.FirstOrDefault(h => h.Name == name);
            if (this.data.Contains(pet)&&pet!=null)
            {
                this.data.Remove(pet);
                return true;
            }
            return false;
        }
        public Pet GetPet(string name, string owner)
        {
            Pet pet1 = this.data.FirstOrDefault(n => n.Name == name);
            string nowner= pet1.Owner;

            if (pet1!=null&& nowner!=null&& pet1.Owner==owner) //????
            {
                return pet1;
            }
            return null;
        }
        public Pet GetOldestPet()
        {
            if (this.data.Count>=1) //>=???
            {
                Pet pet = this.data.OrderByDescending(a => a.Age).FirstOrDefault();
                return pet;
            }
            return null;
        }

        public string GetStatistics()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("The clinic has the following patients:");

            foreach (Pet pet in this.data)
            {
                sb.AppendLine(pet.ToString());
            }

            return sb.ToString().TrimEnd();
        }
    }
}
