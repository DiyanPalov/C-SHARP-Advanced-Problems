﻿using System;

namespace P2.Bee
{
    class Program
    {
        static void Main(string[] args)
        {
            int size = int.Parse(Console.ReadLine());
            char[][] matrix = new char[size][];
            int playerRow = -1;
            int playerCol = -1;
            bool playerFound = false;
            int oldRow = -1;
            int oldCol = -1;
            int polinatedFlowers = 0;
            FillData(size, matrix, ref playerRow, ref playerCol, ref playerFound);

            string command = Console.ReadLine();

            while (command != "End")
            {
                if (command == "up")
                {
                    oldRow = playerRow;
                    oldCol = playerCol;
                    if (playerRow - 1 >= 0)
                    {
                        playerRow--;
                        char symbol = matrix[playerRow][playerCol];
                        MovingUpOrDown(matrix, ref playerRow, playerCol, oldRow, ref polinatedFlowers, ref symbol, oldCol);
                    }
                    else
                    {
                        LoseUpOrDown(matrix, playerRow, playerCol, oldRow);
                        break;
                    }
                }
                else if (command == "down")
                {
                    oldRow = playerRow;
                    oldCol = playerCol;
                    if (playerRow + 1 < size)
                    {
                        playerRow++;
                        char symbol = matrix[playerRow][playerCol];
                        MovingUpOrDown(matrix, ref playerRow, playerCol, oldRow, ref polinatedFlowers, ref symbol, oldCol);
                    }
                    else
                    {
                        LoseUpOrDown(matrix, playerRow, playerCol, oldRow);
                        break;
                    }
                }
                else if (command == "left")
                {
                    oldRow = playerRow;
                    oldCol = playerCol;
                    if (playerCol - 1 >= 0)
                    {
                        playerCol--;
                        char symbol = matrix[playerRow][playerCol];
                        MovingLeftOrRight(matrix, playerRow, ref playerCol, oldRow, oldCol, ref polinatedFlowers, ref symbol);
                    }
                    else
                    {
                        LoseLeftOrRight(matrix, playerRow, playerCol, oldCol);
                        break;
                    }
                }
                else if (command == "right")
                {
                    oldRow = playerRow;
                    oldCol = playerCol;
                    if (playerCol + 1 < size)
                    {
                        playerCol++;
                        char symbol = matrix[playerRow][playerCol];
                        MovingLeftOrRight(matrix, playerRow, ref playerCol, oldRow, oldCol, ref polinatedFlowers, ref symbol);
                    }
                    else
                    {
                        LoseLeftOrRight(matrix, playerRow, playerCol, oldCol);
                        break;
                    }
                }

                command = Console.ReadLine();
            }
            if (polinatedFlowers >= 5)
            {
                Console.WriteLine($"Great job, the bee managed to pollinate {polinatedFlowers} flowers!");
            }
            else
            {
                Console.WriteLine($"The bee couldn't pollinate the flowers, she needed {5 - polinatedFlowers} flowers more");
            }
            for (int row = 0; row < matrix.Length; row++)
            {
                for (int col = 0; col < matrix[row].Length; col++)
                {
                    Console.Write(matrix[row][col]);
                }

                Console.WriteLine();
            }


        }

        private static void LoseLeftOrRight(char[][] matrix, int playerRow, int playerCol, int oldCol)
        {
            matrix[playerRow][playerCol] = 'B';
            matrix[playerRow][oldCol] = '.';
            Console.WriteLine("The bee got lost!");
        }

        private static void LoseUpOrDown(char[][] matrix, int playerRow, int playerCol, int oldRow)
        {
            matrix[playerRow][playerCol] = 'B';
            matrix[oldRow][playerCol] = '.';
            Console.WriteLine("The bee got lost!");
        }

        private static void MovingLeftOrRight(char[][] matrix, int playerRow, ref int playerCol, int oldRow, int oldCol, ref int polinatedFlowers, ref char symbol)
        {
            if (symbol == 'O') //always start
            {
                matrix[playerRow][playerCol] = '.';
                if (oldCol > playerCol) //good
                {
                    playerCol--;
                }
                else
                {
                    playerCol++;
                }
                symbol = matrix[playerRow][playerCol];
            }
            //   oldRow = playerRow;
            //   oldCol = playerCol;
            if (symbol == 'f')
            {
                polinatedFlowers++;
                matrix[playerRow][playerCol] = 'B';
                matrix[playerRow][oldCol] = '.';
            }
            else
            {
                matrix[playerRow][playerCol] = 'B';
                matrix[playerRow][oldCol] = '.';

            }
        }

        private static void MovingUpOrDown(char[][] matrix, ref int playerRow, int playerCol, int oldRow, ref int polinatedFlowers, ref char symbol, int oldCol)
        {
            if (symbol == 'O') //always start
            {
                matrix[playerRow][playerCol] = '.';
                if (oldRow > playerRow) //good
                {
                    playerRow--;
                }
                else
                {
                    playerRow++;
                }
                symbol = matrix[playerRow][playerCol];
            }
            //   oldRow = playerRow;
            //   oldCol = playerCol;
            if (symbol == 'f')
            {
                polinatedFlowers++;
                matrix[playerRow][playerCol] = 'B';
                matrix[oldRow][playerCol] = '.';
            }
            else
            {
                matrix[playerRow][playerCol] = 'B';
                matrix[oldRow][playerCol] = '.';
            }
        }

        private static void FillData(int size, char[][] matrix, ref int playerRow, ref int playerCol, ref bool playerFound)
        {
            for (int row = 0; row < size; row++)
            {
                char[] rowdata = Console.ReadLine().ToCharArray();
                if (!playerFound)
                {
                    for (int col = 0; col < rowdata.Length; col++)
                    {
                        if (rowdata[col] == 'B')
                        {
                            playerRow = row;
                            playerCol = col;
                            playerFound = true;
                            break;
                        }
                    }
                }
                matrix[row] = rowdata;
            }
        }
    }
}
