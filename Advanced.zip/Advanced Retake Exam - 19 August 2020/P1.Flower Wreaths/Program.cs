﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P1.Flower_Wreaths
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] liliesData = Console.ReadLine().Split(", ").Select(int.Parse).ToArray();
            int[] roseData = Console.ReadLine().Split(", ").Select(int.Parse).ToArray();
            int storedFlowers = 0;
            int wreathsCount = 0;

            Stack<int> Lilies = new Stack<int>(liliesData);
            Queue<int> Roses = new Queue<int>(roseData);

            while (Lilies.Count>0&&Roses.Count>0)
            {
                int firstNum = Lilies.Peek();
                int secondNum = Roses.Peek();

                if (firstNum+secondNum>15)
                {
                    Lilies.Push(Lilies.Pop() - 2);
                }
                else if (firstNum+secondNum==15)
                {
                    wreathsCount++;
                    Lilies.Pop();
                    Roses.Dequeue();
                }
                else
                {
                    storedFlowers += firstNum + secondNum;
                    Lilies.Pop();
                    Roses.Dequeue();
                }
            }
            while (storedFlowers>=15)
            {
                storedFlowers -= 15;
                wreathsCount++;
            }
            if (wreathsCount>=5)
            {
                Console.WriteLine($"You made it, you are going to the competition with {wreathsCount} wreaths!");
            }
            else
            {
                Console.WriteLine($"You didn't make it, you need {5-wreathsCount} wreaths more!");
            }
        }
    }
}
