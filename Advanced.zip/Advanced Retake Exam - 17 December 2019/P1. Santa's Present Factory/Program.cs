﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P1._Santa_s_Present_Factory
{
    class Program
    {
        const int DollLevel = 150;
        const int WoodenTrainLevel = 250;
        const int TeddyBearLevel = 300;
        const int BicycleLevel = 400;
        static void Main(string[] args)
        {
            int[] firstNums = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();
            int[] secondNums = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();

            Stack<int> materials = new Stack<int>(firstNums);
            Queue<int> magicLevel = new Queue<int>(secondNums);
            bool dollIsMade = false;
            bool woodenTrainIsMade = false;
            bool teddyBearIsMade = false;
            bool bicycleIsMade = false;
            bool madeList = false;
            int dollCount = 0;
            int woodenTrainCount = 0;
            int teddyBearCount = 0;
            int bicycleCount = 0;
           
            while (materials.Count > 0 && magicLevel.Count > 0)
            {
                int value = materials.Peek() * magicLevel.Peek();

                if (value== DollLevel)
                {
                    dollIsMade = true;
                    dollCount++;
                    madeList = true;
                }
                else if (value== WoodenTrainLevel)
                {
                    woodenTrainIsMade = true;
                    woodenTrainCount++;
                    madeList = true;

                }
                else if (value== TeddyBearLevel)
                {
                    teddyBearIsMade = true;
                    teddyBearCount++;
                    madeList = true;

                }
                else if (value== BicycleLevel)
                {
                    bicycleIsMade = true;
                    bicycleCount++;
                    madeList = true;

                }

                if (madeList==true)
                {
                    materials.Pop();
                    magicLevel.Dequeue();
                    madeList = false;
                }
                if (value<0)
                {
                    int currvalue= materials.Peek() + magicLevel.Peek();
                    materials.Pop();
                    magicLevel.Dequeue();
                    materials.Push(currvalue);
                }
                else if (value>0&&value!=DollLevel&&value!=WoodenTrainLevel&&value!=TeddyBearLevel&&value!=BicycleLevel)
                {
                    materials.Push(materials.Pop() + 15);
                    magicLevel.Dequeue();
                }
                else if (value==0)
                {
                    if (materials.Peek()==0)
                    {
                        materials.Pop();
                    }
                    if (magicLevel.Peek()==0)
                    {
                        magicLevel.Dequeue();
                    }
                   
                }

            }
                if (dollIsMade==true && woodenTrainIsMade==true || teddyBearIsMade==true&& bicycleIsMade==true)
                {
                    Console.WriteLine("The presents are crafted! Merry Christmas!");
                }
            else
            {
                Console.WriteLine("No presents this Christmas!");
            }
            if (materials.Count>0)
            {
                Console.WriteLine($"Materials left: {string.Join(", ",materials)}");
            }
            if (magicLevel.Count>0)
            {
                Console.WriteLine($"Magic left: {string.Join(", ", magicLevel)}");
            }
            if (bicycleCount>=1)
            {
                Console.WriteLine($"Bicycle: {bicycleCount}");
            }
             if (dollCount>=1)
            {
                Console.WriteLine($"Doll: {dollCount}");
            }
            if (teddyBearCount>=1)
            {
                Console.WriteLine($"Teddy bear: {teddyBearCount}");
            }
            if (woodenTrainCount>=1)
            {
                Console.WriteLine($"Wooden train: {woodenTrainCount}");
            }
        }
    }
}
