﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
namespace Christmas
{
   public class Bag
    {
        private List<Present> data;

        private Bag()
        {
            data = new List<Present>();
        }
        public Bag(string color,int capacity):this()
        {
            this.Color = color;
            this.Capacity = capacity;
        }
        public string Color { get; set; }
        public int Capacity { get; set; }

        public int Count => this.data.Count;

        public void Add(Present present)
        {
            if (this.data.Count+1<=Capacity)
            {
                this.data.Add(present);

            }
        }
        public bool Remove(string name)
        {
            Present present = this.data.FirstOrDefault(n => n.Name == name);

            if (this.data.Contains(present))
            {
                this.data.Remove(present);
                return true;
            }
            return false;
        }

        public Present GetHeaviestPresent()
        {
            
            if (this.data.Count >= 1) 
            {
                Present present = this.data.OrderByDescending(w => w.Weight).FirstOrDefault();
                return present;
            }
            return null;
        }
        public Present GetPresent(string name)
        {

            if (this.data.Count >= 1)
            {
                Present present = this.data.FirstOrDefault(n => n.Name == name);
                return present;
            }
            return null;
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{this.Color} bag contains:");

            foreach (Present present in this.data)
            {
                sb.AppendLine(present.ToString());
            }
            return sb.ToString().TrimEnd();
        }
    }
}
