﻿using System;

namespace P2._Present_Delivery
{
    class Program
    {
        static void Main(string[] args)
        {
            int presentsCount = int.Parse(Console.ReadLine());
            int size = int.Parse(Console.ReadLine());
            char[][] matrix = new char[size][];
            int playerRow = -1;
            int playerCol = -1;
            bool playerFound = false;
            int oldRow = -1;
            int oldCol = -1;
            int niceKidCount = 0;
            int happyKids = 0;
            FillMatrix(size, matrix, ref playerRow, ref playerCol, ref playerFound, ref niceKidCount);

            string command = Console.ReadLine();

            while (command != "Christmas morning")
            {
                if (command == "up")
                {
                    oldRow = playerRow;
                    oldCol = playerCol;
                    if (playerRow - 1 >= 0)
                    {
                        playerRow--;
                        MoveUpOrDown(ref presentsCount, matrix, playerRow, playerCol, oldRow, ref happyKids);
                    }
                }
                else if (command == "down")
                {
                    oldRow = playerRow;
                    oldCol = playerCol;
                    if (playerRow + 1 < size)
                    {
                        playerRow++;
                        MoveUpOrDown(ref presentsCount, matrix, playerRow, playerCol, oldRow, ref happyKids);
                    }
                }
                else if (command == "left")
                {
                    oldRow = playerRow;
                    oldCol = playerCol;
                    if (playerCol - 1 >= 0)
                    {
                        playerCol--;
                        MoveLeftOrRight(ref presentsCount, matrix, playerRow, playerCol, oldCol, ref happyKids);
                    }
                }
                else if (command == "right")
                {
                    oldRow = playerRow;
                    oldCol = playerCol;
                    if (playerCol + 1 < size)
                    {
                        playerCol++;
                        MoveLeftOrRight(ref presentsCount, matrix, playerRow, playerCol, oldCol, ref happyKids);
                    }
                }
                if (presentsCount <= 0)
                {
                    Console.WriteLine("Santa ran out of presents!");
                    break;
                }
                command = Console.ReadLine();
            }

            for (int row = 0; row < matrix.Length; row++)
            {
                for (int col = 0; col < matrix[row].Length; col++)
                {
                    Console.Write(matrix[row][col]);
                }

                Console.WriteLine();
            }
            if (niceKidCount == happyKids)
            {
                Console.WriteLine($"Good job, Santa! {happyKids} happy nice kid/s.");
            }
            else
            {
                Console.WriteLine($"No presents for {niceKidCount - happyKids} nice kid/s.");
            }
        }

        private static void MoveLeftOrRight(ref int presentsCount, char[][] matrix, int playerRow, int playerCol, int oldCol, ref int happyKids)
        {
            char symbol = matrix[playerRow][playerCol];

            if (symbol == 'X')
            {
                matrix[playerRow][playerCol] = 'S';
                matrix[playerRow][oldCol] = '-';
            }
            else if (symbol == 'V')
            {
                happyKids++;
                presentsCount--;
                matrix[playerRow][playerCol] = 'S';
                matrix[playerRow][oldCol] = '-';
            }
            else if (symbol == 'C')
            {
                matrix[playerRow][playerCol] = 'S';
                matrix[playerRow][oldCol] = '-';
                if (matrix[playerRow - 1][playerCol] == 'X')
                {
                    matrix[playerRow - 1][playerCol] = '-';
                    presentsCount--;

                }
                else if (matrix[playerRow - 1][playerCol] == 'V')
                {
                    matrix[playerRow - 1][playerCol] = '-';
                    presentsCount--;
                    happyKids++;
                }
                if (matrix[playerRow + 1][playerCol] == 'X')
                {
                    matrix[playerRow + 1][playerCol] = '-';
                    presentsCount--;

                }
                else if (matrix[playerRow + 1][playerCol] == 'V')
                {
                    matrix[playerRow + 1][playerCol] = '-';
                    presentsCount--;
                    happyKids++;
                }
                if (matrix[playerRow][playerCol - 1] == 'X')
                {
                    matrix[playerRow][playerCol - 1] = '-';
                    presentsCount--;

                }
                else if (matrix[playerRow][playerCol - 1] == 'V')
                {
                    matrix[playerRow][playerCol - 1] = '-';
                    presentsCount--;
                    happyKids++;
                }
                if (matrix[playerRow][playerCol + 1] == 'X')
                {
                    matrix[playerRow][playerCol + 1] = '-';
                    presentsCount--;

                }
                else if (matrix[playerRow][playerCol + 1] == 'V')
                {
                    matrix[playerRow][playerCol + 1] = '-';
                    presentsCount--;
                    happyKids++;
                }
            }
            else if (symbol == '-')
            {
                matrix[playerRow][playerCol] = 'S';
                matrix[playerRow][oldCol] = '-';
            }
        }

        private static void MoveUpOrDown(ref int presentsCount, char[][] matrix, int playerRow, int playerCol, int oldRow, ref int happyKids)
        {
            char symbol = matrix[playerRow][playerCol];

            if (symbol == 'X')
            {
                matrix[playerRow][playerCol] = 'S';
                matrix[oldRow][playerCol] = '-';
            }
            else if (symbol == 'V')
            {
                presentsCount--;
                happyKids++;
                matrix[playerRow][playerCol] = 'S';
                matrix[oldRow][playerCol] = '-';
            }
            else if (symbol == 'C')
            {
                matrix[playerRow][playerCol] = 'S';
                matrix[oldRow][playerCol] = '-';
                if (matrix[playerRow - 1][playerCol] == 'X')
                {
                    matrix[playerRow - 1][playerCol] = '-';
                    presentsCount--;

                }
                else if (matrix[playerRow - 1][playerCol] == 'V')
                {
                    matrix[playerRow - 1][playerCol] = '-';
                    presentsCount--;
                    happyKids++;
                }
                if (matrix[playerRow + 1][playerCol] == 'X')
                {
                    matrix[playerRow + 1][playerCol] = '-';
                    presentsCount--;

                }
                else if (matrix[playerRow + 1][playerCol] == 'V')
                {
                    matrix[playerRow + 1][playerCol] = '-';
                    presentsCount--;
                    happyKids++;
                }
                if (matrix[playerRow][playerCol - 1] == 'X')
                {
                    matrix[playerRow][playerCol - 1] = '-';
                    presentsCount--;

                }
                else if (matrix[playerRow][playerCol - 1] == 'V')
                {
                    matrix[playerRow][playerCol - 1] = '-';
                    presentsCount--;
                    happyKids++;
                }
                if (matrix[playerRow][playerCol + 1] == 'X')
                {
                    matrix[playerRow][playerCol + 1] = '-';
                    presentsCount--;

                }
                else if (matrix[playerRow][playerCol + 1] == 'V')
                {
                    matrix[playerRow][playerCol + 1] = '-';
                    presentsCount--;
                    happyKids++;
                }
            }
            else if (symbol == '-')
            {
                matrix[playerRow][playerCol] = 'S';
                matrix[oldRow][playerCol] = '-';
            }
        }
        private static void FillMatrix(int size, char[][] matrix, ref int playerRow, ref int playerCol, ref bool playerFound, ref int niceKidCount)
        {
            for (int row = 0; row < size; row++)
            {
                char[] rowdata = Console.ReadLine().ToCharArray();
                if (!playerFound)
                {
                    for (int col = 0; col < rowdata.Length; col++)
                    {
                        if (rowdata[col] == 'S')
                        {
                            playerRow = row;
                            playerCol = col;
                            playerFound = true;

                        }
                        if (rowdata[col] == 'V')
                        {
                            niceKidCount++;
                        }
                    }
                }
                matrix[row] = rowdata;
            }
        }
    }
}
