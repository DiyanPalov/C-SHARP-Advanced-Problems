﻿using System;
using System.Linq;

namespace _2._Knights_of_Honor
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] names = Console.ReadLine().Split(' ').ToArray();

            Action<string> action = (string n) => Console.WriteLine("Sir"+ " "+n);

            for (int i = 0; i < names.Length; i++)
            {
                action(names[i]);
            }
        }
    }
}
