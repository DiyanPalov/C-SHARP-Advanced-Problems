﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _4._Find_Evens_or_Odds
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] range = Console.ReadLine().Split(" ",StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
            string command = Console.ReadLine();

            if (command=="odd")
            {
                Predicate<int> predicate = (int n) =>
                  {
                      return n % 2 != 0;
                  };
                List<int> odd = new List<int>();
                for (int i = range[0]; i <= range[1]; i++)
                {
                    bool currOdd = predicate(i);
                    if (currOdd)
                    {
                        int curr = i;
                        odd.Add(curr);
                    }
                }
                Console.WriteLine(string.Join(" ",odd));
            }
            else
            {
                Predicate<int> predicate = (int n) =>
                {
                    return n % 2 == 0;
                };

                List<int> even = new List<int>();
                for (int i = range[0]; i <=  range[1]; i++)
                {
                    bool currEven = predicate(i);
                    if (currEven)
                    {
                        int curr = i;
                        even.Add(curr);
                    }
                }
                Console.WriteLine(string.Join(" ", even));
            }
        }
    }
}
