﻿using System;
using System.Linq;

namespace _3._Custom_Min_Function
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] nums = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();

            Func<int, int> func = (name) => 
            {
                int smallest = nums.Min();
               
               return  smallest;
            };
            int result = func(nums[nums.Length-1]);
            Console.WriteLine(result);
        }
    }

}