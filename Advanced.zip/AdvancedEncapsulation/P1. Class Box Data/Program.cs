﻿using System;

namespace P1._Class_Box_Data
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
