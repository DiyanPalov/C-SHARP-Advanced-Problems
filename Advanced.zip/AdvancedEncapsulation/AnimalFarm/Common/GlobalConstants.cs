﻿namespace AnimalFarm.Common
{
    public class GlobalConstants
    {
        public static string InvalidNameExceptionMessage = "Name cannot be empty.";

        public static string InvalidAgeExcepionMessage = "Age should be between {0} and {1}.";
    }
}
