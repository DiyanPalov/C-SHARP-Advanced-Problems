﻿using AnimalFarm.Core;

namespace AnimalFarm
{
    public class StartUp
    {
        static void Main()
        {
            var engine = new Engine();

            engine.Run();
        }
    }
}
