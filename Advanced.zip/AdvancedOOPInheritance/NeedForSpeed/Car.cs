﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    public class Car : Vehicle
    {
        public Car(int horsePower, double fuel) : base(horsePower, fuel)
        {
        }
        public virtual double DefaultFuelConsumptionCar { get; set; } = 3;

        public override double FuelConsumption => DefaultFuelConsumptionCar;

        public override void Drive(double kilometers)
        {
            double FuelAfter = Fuel - kilometers * FuelConsumption;
            if (FuelAfter >= 0)
            {
                Fuel = FuelAfter;
            }
        }
    }
}
