﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
   public class RaceMotorcycle : Motorcycle
    {
        public RaceMotorcycle(int horsePower, double fuel):base( horsePower,  fuel)
        {

        }
        public virtual double DefaultFuelConsumptionRace { get; set; } = 8;

        public override double FuelConsumption => DefaultFuelConsumptionRace;

        public override void Drive(double kilometers)
        {
            double FuelAfter = Fuel - kilometers * FuelConsumption;
            if (FuelAfter >= 0)
            {
                Fuel = FuelAfter;
            }
        }
    }
}
