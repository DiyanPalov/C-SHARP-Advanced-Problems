﻿using System;

namespace task
{
   public class Program
    {
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            double x = double.Parse(Console.ReadLine());

          //  Console.WriteLine(Sum3(x,a));
        }

        //private static double Sum3(double x, int a)
        //{
        // //   return Math.Pow((x+a),3);
        //}
    }
}
