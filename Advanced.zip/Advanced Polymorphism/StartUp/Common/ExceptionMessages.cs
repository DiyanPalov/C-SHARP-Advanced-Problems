﻿
namespace Raiding.Common
{
    public class ExceptionMessages
    {
        public static string InvalidHeroException = "Invalid hero!";
    }
}
