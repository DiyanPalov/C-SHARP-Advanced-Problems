﻿using System;
using System.Collections.Generic;
using System.Text;
using Vehicles.Commom;
using Vehicles.Models;

namespace Vehicles.Factories
{
    //factory pattern!!!
  public  class VehicleFactory
    {

        public VehicleFactory()
        {

        }

        // most times is not that way but we dont know reflaction
        public Vehacle CreateVehicle(string vehicleType, double fuelquantity, double fuelconsumption)
        {
            Vehacle vehacle;
            if (vehicleType=="Car")
            {
                vehacle = new Car(fuelquantity, fuelconsumption);
            }
            else if (vehicleType=="Truck")
            {
                vehacle = new Truck(fuelquantity, fuelconsumption);
            }
            else
            {
                throw new InvalidOperationException(ExceptionMessage.INVALID_TYPE);
            }

            return vehacle;
        }
    }
}
