﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Models
{
    public class Truck : Vehacle
    {
        private const double REFUEL_SUCC = 0.95;
        private const double FUEL_COMP_INCREMENT = 1.6;
        public Truck(double fuelquantity, double fuelConsumption) : base(fuelquantity, fuelConsumption)
        {
        }

        public override double FuelConsumtion => base.FuelConsumtion + FUEL_COMP_INCREMENT;

        public override void Refuel(double amount)
        {
            base.Refuel(amount* REFUEL_SUCC);
        }
    }
}
