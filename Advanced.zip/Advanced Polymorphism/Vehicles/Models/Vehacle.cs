﻿using System;
using System.Collections.Generic;
using System.Text;
using Vehicles.Commom;
using Vehicles.Models.Contracts;

namespace Vehicles.Models
{
    public abstract class Vehacle : IDriveable,IRefuelable
    {

        private const string SUCC_DRIVE_MESSAGE = "{0} travelled {1} km";

        protected Vehacle(double fuelquantity, double fuelConsumption)
        {
            this.FuelQuantity = fuelquantity;
            this.FuelConsumtion = fuelConsumption;
        }
        public double FuelQuantity { get; private set; }

        public virtual double FuelConsumtion { get; private set; }

        public string Drive(double amount)
        {
            double fuelNeeded = amount * this.FuelConsumtion;

            if (this.FuelQuantity<fuelNeeded)
            {
                throw new InvalidOperationException(String.Format(ExceptionMessage.NotEnoughFuel, this.GetType().Name));
            }

            this.FuelQuantity -= fuelNeeded;

            return String.Format(SUCC_DRIVE_MESSAGE,this.GetType().Name, amount);
        }

        public virtual void Refuel(double amount)
        {
            if (amount<0)
            {
                throw new InvalidOperationException(ExceptionMessage.NegativeFuelMSG);
            }
            this.FuelQuantity += amount;
        }

        public override string ToString()
        {
            return $"{this.GetType().Name}: {this.FuelQuantity:f2}";
        }
    }
}
