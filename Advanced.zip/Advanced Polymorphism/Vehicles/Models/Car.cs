﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Models
{
    public class Car : Vehacle
    {

        private const double Fuel_Consumption_Increment = 0.9;
        public Car(double fuelquantity, double fuelConsumption) : base(fuelquantity, fuelConsumption)
        {

        }

        public override double FuelConsumtion => base.FuelConsumtion + Fuel_Consumption_Increment;

        
    }
}
