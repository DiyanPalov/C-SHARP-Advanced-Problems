﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Commom
{
    public static class ExceptionMessage
    {
        public const string NotEnoughFuel = "{0} needs refueling";

        public const string NegativeFuelMSG= "Fuel must be a positive number";

        public const string INVALID_TYPE = "Invalid Vehicle Type!";
    }
}
