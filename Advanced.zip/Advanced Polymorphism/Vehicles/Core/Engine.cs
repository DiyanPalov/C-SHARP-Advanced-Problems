﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Vehicles.Core.Contracts;
using Vehicles.Factories;
using Vehicles.Models;

namespace Vehicles.Core
{
    public class Engine : IEngine
    {
        private readonly VehicleFactory vehicleFactory;
      //  private readonly Vehacle car;
      //  private readonly Vehacle truck;

        public Engine()
        {
            this.vehicleFactory = new VehicleFactory();
        }
        public void Run()
        {
           Vehacle car= this.ProcessCarInfo();
           Vehacle truck= this.ProcessCarInfo();

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] tokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();

                string cmndType = tokens[0];
                string vehicleType = tokens[1];
                double args = double.Parse(tokens[2]);
                try
                {
                    if (cmndType == "Drive")
                    {
                        if (vehicleType == "Car")
                        {
                            this.Drive(car, args);
                        }
                        else if (vehicleType == "Truck")
                        {
                            this.Drive(truck, args);
                        }
                    }
                    else if (cmndType == "Refuel")
                    {
                        if (vehicleType == "Car")
                        {
                            this.Refuel(car, args);
                        }
                        else if (vehicleType == "Truck")
                        {
                            this.Refuel(truck, args);
                        }
                    }
                }
                catch (InvalidOperationException e)
                {

                    Console.WriteLine(e.Message);
                }
               
            }

            Console.WriteLine(car);
            Console.WriteLine(truck);
        }

        private void Refuel(Vehacle vehacle, double amount)
        {
            vehacle.Refuel(amount);
        }
        private void Drive(Vehacle vehacle, double kilometers)
        {
            Console.WriteLine(vehacle.Drive(kilometers));
           
        }
        private Vehacle ProcessCarInfo()
        {
            string[] carArg = Console.ReadLine().Split(" ",StringSplitOptions.RemoveEmptyEntries).ToArray();

            string vehicleType = carArg[0];
            double fuelquantity = double.Parse(carArg[1]);
            double fuelConsumption = double.Parse(carArg[2]);

            Vehacle currVehacle = this.vehicleFactory.CreateVehicle(vehicleType, fuelquantity, fuelConsumption);

            return currVehacle;
        }
    }
}
