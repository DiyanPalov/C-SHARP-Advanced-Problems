﻿using System;
using Test.Core;
using Test.Models;

namespace Test
{
  public  class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
