﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Test.Common
{
  public  class ExeptionMessages
    {
        public static string InvalidHeroException = "Invalid hero!";
    }
}
