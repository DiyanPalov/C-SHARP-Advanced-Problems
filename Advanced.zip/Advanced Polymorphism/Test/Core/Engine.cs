﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Test.Factories;
using Test.Models;

namespace Test.Core
{
    public class Engine
    {
        private readonly List<BaseHero> heroes;
        private HeroFactory heroFactory;

        public Engine()
        {
            this.heroes = new List<BaseHero>();
            this.heroFactory = new HeroFactory();

        }

        public void Run()
        {
            FormTheGroupRaid();
            int bossPower = int.Parse(Console.ReadLine());
            int heroesPower = 0;

            if (this.heroes.Count != 0)
            {
                foreach (var item in this.heroes)
                {
                    Console.WriteLine(item.CastAbility());
                }
                heroesPower = this.heroes.Sum(h => h.Power);
            }


            Console.WriteLine(heroesPower >= bossPower ?
               "Victory!" : "Defeat...");

        }

        private void FormTheGroupRaid()
        {
            int count = int.Parse(Console.ReadLine());

            while (count > this.heroes.Count)
            {
                BaseHero hero=null;

                try
                {
                    string name = Console.ReadLine();
                    string type = Console.ReadLine();
                    hero = this.heroFactory.CreateHero(type, name);
                }
                catch (ArgumentException msg)
                {
                    Console.WriteLine(msg.Message);
                    continue;
                }
                if (hero != null)
                {
                    this.heroes.Add(hero);
                }
            }
        }
    }
}
