﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace AdvancedExam_28_June_2020
{
   public class Startup
    {
        private const int DaturaBombs= 40;
        private const int CherryBombs= 60;
        private const int SmokeDecoyBombs= 120;
        static void Main(string[] args)
        {
            int[] bombEffect = Console.ReadLine()
                .Split(", ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse).ToArray();

            int[] bombCasting = Console.ReadLine()
                .Split(", ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse).ToArray();

            Queue<int> effect = new Queue<int>(bombEffect);
            Stack<int> casting = new Stack<int>(bombCasting);

            int CherryBombCount = 0;
            int DaturaBombCount = 0;
            int SmokeDecoyBombCount = 0;
            NewMethod(effect, casting, ref CherryBombCount, ref DaturaBombCount, ref SmokeDecoyBombCount);
            if (effect.Count == 0)
            {
                Console.WriteLine("Bomb Effects: empty");
            }
            else
            {
                Console.WriteLine($"Bomb Effects: {string.Join(", ", effect)}");
            }
            if (casting.Count == 0)
            {
                Console.WriteLine("Bomb Casings: empty");
            }
            else
            {
                Console.WriteLine($"Bomb Casings: {string.Join(", ", casting)}");
            }

            Console.WriteLine($"Cherry Bombs: {CherryBombCount}");
            Console.WriteLine($"Datura Bombs: {DaturaBombCount}");
            Console.WriteLine($"Smoke Decoy Bombs: {SmokeDecoyBombCount}");
        }

        private static void NewMethod(Queue<int> effect, Stack<int> casting, ref int CherryBombCount, ref int DaturaBombCount, ref int SmokeDecoyBombCount)
        {
            while (effect.Count > 0 && casting.Count > 0)
            {
                int firstNum = effect.Peek();
                int secondNum = casting.Peek();

                if (firstNum + secondNum == DaturaBombs)
                {
                    effect.Dequeue();
                    casting.Pop();
                    DaturaBombCount++;
                }
                else if (firstNum + secondNum == CherryBombs)
                {
                    effect.Dequeue();
                    casting.Pop();
                    CherryBombCount++;
                }
                else if (firstNum + secondNum == SmokeDecoyBombs)
                {
                    effect.Dequeue();
                    casting.Pop();
                    SmokeDecoyBombCount++;
                }
                else
                {

                    int current = casting.Pop();
                    casting.Push(current - 5);



                }

                if (DaturaBombCount >= 3 && CherryBombCount >= 3 && SmokeDecoyBombCount >= 3)
                {
                    Console.WriteLine($"Bene! You have successfully filled the bomb pouch!");
                    break;
                }
                else if (effect.Count == 0 || casting.Count == 0)
                {
                    Console.WriteLine($"You don't have enough materials to fill the bomb pouch.");
                    break;
                }
            }
        }
    }
}
