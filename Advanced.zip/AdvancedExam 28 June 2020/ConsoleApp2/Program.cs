﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] size = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();
            
            int[,] matrix = new int[size[0], size[1]];
            int numRows = size[0];
            int numCols = size[1];



            FillMatrix(matrix, numRows, numCols);

            string command = Console.ReadLine();

            while (command != "Bloom Bloom Plow")
            {
                string[] tokens = command.Split(" ").ToArray();
                int RowPossition = int.Parse(tokens[0]);
                int ColPossiotion = int.Parse(tokens[1]);

                if (RowPossition >= 0 && RowPossition < matrix.GetLength(0) && ColPossiotion >= 0 && ColPossiotion < matrix.GetLength(1))
                {
                    matrix[RowPossition,ColPossiotion]  +=1;

                    for (int i = RowPossition; i < RowPossition + 1; i++)
                    {
                        for (int j = 0; j < size[1]; j++)
                        {
                            if (i==RowPossition&& j==ColPossiotion)
                            {

                            }
                            else
                            {
                                matrix[i, j] += 1; //!!
                                matrix[j, i] += 1;
                            }
                           
                        }
                    }

                    //for (int k = ColPossiotion; k < ColPossiotion + 1; k++) //SIZE ?? 
                    //{
                    //    for (int Z = 0; Z < size[0]; Z++)
                    //    {
                    //        matrix[Z, k] += 1;
                    //    }
                    //}
                }
                else
                {
                    Console.WriteLine("Invalid coordinates.");
                }

                command = Console.ReadLine();
            }


            for (int row = 0; row < size[0]; row++)
            {
                for (int col = 0; col < size[1]; col++)
                {
                    Console.Write("{0 }", matrix[row, col], matrix[row, col]); //!!!
                }

                Console.WriteLine();
            }

        }

        private static void FillMatrix(int[,] matrix, int numRows, int numCols)
        {
            for (int i = 0; i < numRows; ++i)
            {
                for (int j = 0; j < numCols; ++j)
                {
                    matrix[i, j] = 0;
                }
            }
        }
    }
}
