﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ExamPrep
{
    class Program
    {
        static void Main(string[] args)
        {
            int size = int.Parse(Console.ReadLine());
            int commandCount = int.Parse(Console.ReadLine());

            char[][] matrix = new char[size][];
            int playerRow = -1;
            int playerCol = -1;
            bool playerPosFound = false;
            bool isWon = false;
            FillMatrix(size, matrix, ref playerRow, ref playerCol, ref playerPosFound);


            for (int i = 0; i < commandCount; i++)
            {
                string command = Console.ReadLine();
                matrix[playerRow][playerCol] = '-';

                if (command == "up")
                {
                    if (playerRow - 1 >= 0)
                    {
                        playerRow--;
                    }
                    else
                    {
                        playerRow = matrix[playerRow].Length - 1;

                    }
                    while (matrix[playerRow][playerCol] != '-' && matrix[playerRow][playerCol] != 'F')
                    {
                        if (matrix[playerRow][playerCol] == 'T')
                        {
                            playerRow++;
                        }
                        else if (matrix[playerRow][playerCol] == 'B')
                        {
                            playerRow--;
                        }

                        if (playerRow < 0)
                        {
                            playerRow = matrix[playerRow].Length - 1;
                        }

                    }
                    if (matrix[playerRow][playerCol] == 'F')
                    {
                        isWon = true;
                        break;
                    }
                    matrix[playerRow][playerCol] = 'f';
                }

                else if (command == "down")
                {
                    if (playerRow + 1 < matrix.Length)
                    {
                        playerRow++;
                    }
                    else
                    {
                        playerRow = 0;
                    }
                    while (matrix[playerRow][ playerCol] != '-' && matrix[playerRow][playerCol] != 'F')
                    {
                        if (matrix[playerRow][playerCol] == 'T')
                        {
                            playerRow--;
                        }
                        else if (matrix[playerRow][playerCol] == 'B')
                        {
                            playerRow++;
                        }

                        if (playerRow == matrix.Length)
                        {
                            playerRow = 0;
                        }

                    }

                    if (matrix[playerRow][playerCol] == 'F')
                    {
                        isWon = true;
                        break;
                    }
                    matrix[playerRow][playerCol] = 'f';

                }
                else if (command == "left")
                {
                    if (playerCol - 1 >= 0)
                    {
                        playerCol--;
                    }
                    else
                    {
                        playerCol = matrix.Length - 1;
                    }

                    while (matrix[playerRow][ playerCol] != '-' && matrix[playerRow][playerCol] != 'F')
                    {
                        if (matrix[playerRow][playerCol] == 'T')
                        {
                            playerCol++;
                        }
                        else if (matrix[playerRow][playerCol] == 'B')
                        {
                            playerCol--;
                        }
                        if (playerCol < 0)
                        {
                            playerCol = matrix.Length - 1;
                        }

                    }
                    if (matrix[playerRow][playerCol] == 'F')
                    {
                        isWon = true;
                        break;
                    }
                    matrix[playerRow][playerCol] = 'f';
                }
                else if (command == "right")
                {
                    if (playerCol + 1 < matrix[playerCol].Length)
                    {
                        playerCol++;
                    }
                    else
                    {
                        playerCol = 0;
                    }

                    while (matrix[playerRow][playerCol] != '-' && matrix[playerRow][playerCol] != 'F')
                    {
                        if (matrix[playerRow][playerCol] == 'T')
                        {
                            playerCol--;
                        }
                        else if (matrix[playerRow][playerCol] == 'B')
                        {
                            playerCol++;
                        }

                        if (playerCol == matrix[playerCol].Length)
                        {
                            playerCol = 0;
                        }

                    }
                    if (matrix[playerRow][playerCol] == 'F')
                    {
                        isWon = true;
                        break;
                    }
                    matrix[playerRow][playerCol] = 'f';
                }
            }
            if (isWon)
            {
                matrix[playerRow][playerCol] = 'f';
                Console.WriteLine("Player won!");
            }
            else
            {
                Console.WriteLine("Player lost!");
            }

            PrintMatrix(size, matrix);
        }

        private static void PrintMatrix(int size, char[][] matrix)
        {
            for (int row = 0; row < size; row++)
            {
                for (int col = 0; col < size; col++)
                {
                    Console.Write(matrix[row][col]);
                }
                Console.WriteLine();
            }
        }

        private static void FillMatrix(int size, char[][] matrix, ref int playerRow, ref int playerCol, ref bool playerPosFound)
        {
            for (int row = 0; row < size; row++)
            {
                char[] rowdata = Console.ReadLine().ToCharArray();
                if (!playerPosFound)
                {

                    for (int col = 0; col < rowdata.Length; col++)
                    {

                        if (rowdata[col] == 'f')
                        {
                            playerRow = row;
                            playerCol = col;
                            playerPosFound = true;
                            break;
                        }

                    }
                }
                matrix[row] = rowdata;
            }
        }
    }
}
