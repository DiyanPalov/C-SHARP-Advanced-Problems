﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VetClinic
{
    public class Clinic
    {
        private List<Pet> data;
        private int capacity;

        private Clinic()
        {
            this.data = new List<Pet>();
        }

        public Clinic(int cap) : this()
        {
            this.Capacity = capacity;
        }
        public int Capacity { get; set; }

        public int Count => this.data.Count;

        public void Add(Pet pet)
        {
            if (this.data.Count + 1 <= Capacity)
            {
                this.data.Add(pet);
            }
        }

        public bool Remove(string name)
        {

            Pet pet = this.data.FirstOrDefault(n => n.Name == name);

            if (pet != null)
            {
                this.data.Remove(pet);
                return true;
            }
            return false;
        }

        public Pet GetPet(string name, string owner)
        {
           
            Pet pet = this.data.FirstOrDefault(n => n.Name == name && n.Owner == owner);

            if (pet != null)
            {
                return pet;
            }
            return null;
        }

        public Pet GetOldestPet() 
        {
            if (this.data.Count>=1 ) //maybe >= 1 
            {
                Pet pet = this.data.OrderByDescending(p => p.Age).FirstOrDefault();

                return pet;
            }
            return null;
        }

        public string GetStatistics()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("The clinic has the following patients:");

            foreach (Pet pet in this.data)
            {
                sb.AppendLine(pet.ToString());
            }
            return sb.ToString().TrimEnd();
        }
    }
}
