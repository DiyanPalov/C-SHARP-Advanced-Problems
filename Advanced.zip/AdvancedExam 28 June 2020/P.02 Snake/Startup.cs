﻿using System;
using System.Linq;

namespace P._02_Snake
{
    public class Startup
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            char[][] matrix = new char[n][];

            int playerRow = -1;
            int playerCol = -1;
            
            bool playerPosFound = false;
            FillData(n, matrix, ref playerRow, ref playerCol, ref playerPosFound);

            int foodCount = 0;
            string command = Console.ReadLine();

            while (foodCount!=10)
            {
                if (command == "up")
                {
                    int oldRow = playerRow;
                    int oldCol = playerCol;
                    if (playerRow - 1 >= 0)
                    {
                        
                        playerRow--;
                        char symbol = matrix[playerRow][playerCol];

                        if (symbol=='*')
                        {
                            foodCount++;
                            matrix[playerRow][playerCol] = 'S';
                            matrix[playerRow + 1][playerCol] = '.';
                        }
                        else if (symbol=='-')
                        {
                            matrix[playerRow][playerCol] = 'S';
                            matrix[playerRow + 1][playerCol] = '.';
                        }
                        else if (symbol=='B')
                        {
                            
                            matrix[playerRow][playerCol] = '.';
                            matrix[oldRow][oldCol] = '.';//test

                            for (int row = 0; row < n; row++)
                            {
                                for (int col = 0; col < n; col++)
                                {
                                    char currentChar = matrix[row][col];

                                    if (currentChar=='B')
                                    {
                                        playerRow = row;
                                        playerCol = col;
                                        matrix[playerRow][playerCol] = 'S';
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        matrix[oldRow][oldCol] = '.';
                       // matrix[playerRow - 1][playerCol] = '.';
                        break;
                    }
                }
                else if (command == "down")
                {
                    int oldRow = playerRow;
                    int oldCol = playerCol;
                    if (playerRow + 1 < n)
                    {
                        //int oldRow = playerRow;
                        //int oldCol = playerCol;
                        playerRow++;
                        char symbol = matrix[playerRow][playerCol];

                        if (symbol == '*')
                        {
                            foodCount++;
                            matrix[playerRow][playerCol] = 'S';
                            matrix[playerRow - 1][playerCol] = '.';
                        }
                        else if (symbol == '-')
                        {
                            matrix[playerRow][playerCol] = 'S';
                            matrix[playerRow - 1][playerCol] = '.';
                        }
                        else if (symbol == 'B')
                        {

                            matrix[playerRow][playerCol] = '.';
                            matrix[oldRow][oldCol] = '.';//test

                            for (int row = 0; row < n; row++)
                            {
                                for (int col = 0; col < n; col++)
                                {
                                    char currentChar = matrix[row][col];

                                    if (currentChar == 'B')
                                    {
                                        playerRow = row;
                                        playerCol = col;
                                        matrix[playerRow][playerCol] = 'S';
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        matrix[oldRow][oldCol] = '.';
                      //  matrix[playerRow - 1][playerCol] = '.';

                        break;
                    }
                }
                else if (command == "left")
                {
                        int oldRow = playerRow;
                        int oldCol = playerCol;
                    if (playerCol - 1 >= 0)
                    {
                        playerCol--;
                        char symbol = matrix[playerRow][playerCol];

                        if (symbol == '*')
                        {
                            foodCount++;
                            matrix[playerRow][playerCol] = 'S';
                            matrix[playerRow][playerCol+1] = '.';
                        }
                        else if (symbol == '-')
                        {
                            matrix[playerRow][playerCol] = 'S';
                            matrix[playerRow][playerCol+1] = '.';
                        }
                        else if (symbol == 'B')
                        {

                            matrix[playerRow][playerCol] = '.';
                            matrix[oldRow][oldCol] = '.';//test

                            for (int row = 0; row < n; row++)
                            {
                                for (int col = 0; col < n; col++)
                                {
                                    char currentChar = matrix[row][col];

                                    if (currentChar == 'B')
                                    {
                                        playerRow = row;
                                        playerCol = col;
                                        matrix[playerRow][playerCol] = 'S';
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        matrix[oldRow][oldCol] = '.';
                      //  matrix[playerRow - 1][playerCol] = '.';

                        break;
                    }
                }
                else if (command == "right")
                {
                        int oldRow = playerRow;
                        int oldCol = playerCol;
                    if (playerCol + 1 < n)
                    {
                        playerCol++;
                        char symbol = matrix[playerRow][playerCol];

                        if (symbol == '*')
                        {
                            foodCount++;
                            matrix[playerRow][playerCol] = 'S';
                            matrix[playerRow][playerCol - 1] = '.';
                        }
                        else if (symbol == '-')
                        {
                            matrix[playerRow][playerCol] = 'S';
                            matrix[playerRow][playerCol - 1] = '.';
                        }
                        else if (symbol == 'B')
                        {

                            matrix[playerRow][playerCol] = '.';
                            matrix[oldRow][oldCol] = '.';//test

                            for (int row = 0; row < n; row++)
                            {
                                for (int col = 0; col < n; col++)
                                {
                                    char currentChar = matrix[row][col];

                                    if (currentChar == 'B')
                                    {
                                        playerRow = row;
                                        playerCol = col;
                                        matrix[playerRow][playerCol] = 'S';
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        matrix[oldRow][oldCol] = '.';
                      //  matrix[playerRow - 1][playerCol] = '.';
                        break;
                    }
                }
                command = Console.ReadLine();
            }
            if (foodCount >= 10)
            {
                Console.WriteLine("You won! You fed the snake.");
                Console.WriteLine($"Food eaten: {foodCount}");
            }
            else
            {
                Console.WriteLine("Game over!");
                Console.WriteLine($"Food eaten: {foodCount}");
            }

            for (int row = 0; row < matrix.Length; row++)
            {
                for (int col = 0; col < matrix[row].Length; col++)
                {
                    Console.Write(matrix[row][col]);
                }

                Console.WriteLine();
            }
        }

      

        private static void FillData(int n, char[][] matrix, ref int playerRow, ref int playerCol, ref bool playerPosFound)
        {
            for (int row = 0; row < n; row++)
            {
                char[] rowdata = Console.ReadLine().ToCharArray();
                if (!playerPosFound)
                {


                    for (int col = 0; col < rowdata.Length; col++)
                    {
                        if (rowdata[col] == 'S')
                        {
                            playerRow = row;
                            playerCol = col;                            
                            playerPosFound = true;
                            break;
                        }
                    }
                }
                matrix[row] = rowdata;
            }
        }
    }
}
