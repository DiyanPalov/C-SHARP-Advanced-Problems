﻿using System;

namespace quiz
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
