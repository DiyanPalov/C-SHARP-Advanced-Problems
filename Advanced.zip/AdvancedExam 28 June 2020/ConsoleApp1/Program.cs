﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tasksData = Console.ReadLine().Split(", ").Select(int.Parse).ToArray();
            int[] threadData = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();

            int ToKill = int.Parse(Console.ReadLine());
            int lastKnown = 0;
            Stack<int> tasks = new Stack<int>(tasksData);
            Queue<int> threads = new Queue<int>(threadData);

            while (true)
            {
               
                if (threads.Peek()>=tasks.Peek())
                {
                    threads.Dequeue();
                    tasks.Pop();
                }
                else if (threads.Peek()<tasks.Peek())
                {
                    threads.Dequeue();
                }

                if (tasks.Peek()== ToKill)
                {
                    break;
                }
            }
            Console.WriteLine($"Thread with value {threads.Peek()} killed task {ToKill}");
            Console.WriteLine($"{ string.Join(" ", threads)}");
        }
    }
}
