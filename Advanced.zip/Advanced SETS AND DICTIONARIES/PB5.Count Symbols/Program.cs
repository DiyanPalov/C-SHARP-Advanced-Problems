﻿using System;
using System.Linq;
using System.Collections.Generic;
namespace PB5.Count_Symbols
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<char, int> symbols = new Dictionary<char, int>();
            char[] data = Console.ReadLine().ToCharArray();

            for (int i = 0; i < data.Length; i++)
            {
                if (!symbols.ContainsKey(data[i]))
                {
                    symbols.Add(data[i],1);
                }
                else
                {
                    symbols[data[i]]++;
                }
            }

            foreach (var chare in symbols.OrderBy(c=>c.Key))
            {
                Console.WriteLine($"{chare.Key}: {chare.Value} time/s");
            }
        }
    }
}
