﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Pb4.EvenTimes
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, int> numbersData = new Dictionary<int, int>();
            numbersData = AddNumbers(numbersData);

            int searchedNumber = numbersData.FirstOrDefault(x => x.Value % 2 == 0).Key;
            Console.WriteLine(searchedNumber);
        }

        static Dictionary<int, int> AddNumbers(Dictionary<int, int> numbersData)
        {
            int numbersCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < numbersCount; i++)
            {
                int number = int.Parse(Console.ReadLine());

                if (numbersData.ContainsKey(number))
                {
                    numbersData[number]++;
                }

                else
                {
                    numbersData.Add(number, 1);
                }
            }

            return numbersData;
        }
    }
}