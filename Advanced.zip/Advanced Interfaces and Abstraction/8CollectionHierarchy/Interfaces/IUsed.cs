﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _8CollectionHierarchy.Interfaces
{
    public interface IUsed
    {
        int Used { get; }
    }
}
