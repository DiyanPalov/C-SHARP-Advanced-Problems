﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _8CollectionHierarchy.Interfaces
{
    public interface IAdd
    {
        int Add(string element);
    }
}
