﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Exceptions
{
  public  class InvalidURLEx : Exception
    {
        private const string INVALID_URL= "Invalid URL!";

        public InvalidURLEx():base(INVALID_URL)
        {

        }
    }
}
