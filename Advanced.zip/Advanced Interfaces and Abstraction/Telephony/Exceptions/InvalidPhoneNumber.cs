﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Exceptions
{
  public  class InvalidPhoneNumber :Exception
    {
        private const string INVALID_PHONE = "Invalid number!";

        public InvalidPhoneNumber() : base(INVALID_PHONE)
        {

        }
    }
}
