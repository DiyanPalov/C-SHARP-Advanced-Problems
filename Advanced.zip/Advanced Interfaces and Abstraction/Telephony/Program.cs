﻿using System;
using Telephony.Exceptions;

namespace Telephony
{
  public  class Program
    {
        static void Main(string[] args)
        {
            string[] phoneNumber = Console.ReadLine().Split(" ");
            string[] sites = Console.ReadLine().Split(" ");

            StationaryPhone stationaryPhone = new StationaryPhone();
            Smartphone smartphone = new Smartphone();

            for (int i = 0; i < phoneNumber.Length; i++)
            {
                if (phoneNumber[i].Length ==7)
                {
                    Console.WriteLine(stationaryPhone.Call(phoneNumber[i])); 
                }

                else if (phoneNumber[i].Length == 10)
                {
                    Console.WriteLine(smartphone.Call(phoneNumber[i]));
                }
                else
                {
                    throw new InvalidPhoneNumber();
                }
            }

            for (int j = 0; j < sites.Length; j++)
            {
                try
                {
                    Console.WriteLine(smartphone.Browse(sites[j]));
                }
                catch (InvalidURLEx ex)
                {

                    Console.WriteLine(ex.Message);
                }
                
            }
          
        }
    }
}
