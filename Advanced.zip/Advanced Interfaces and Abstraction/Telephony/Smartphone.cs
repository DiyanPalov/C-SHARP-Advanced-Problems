﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Telephony.Exceptions;

namespace Telephony
{
    using Telephony.Exceptions;
    public class Smartphone : ICalling, IBrowser
    {
        public string Browse(string site)
        {
            if (site.Any(x=>char.IsDigit(x)))
            {
                throw new InvalidURLEx();
            }

            return $"Browsing: {site}!";
        }


        public string Call(string number)
        {
            if (!number.All(d => char.IsDigit(d)))
            {
                throw new InvalidPhoneNumber();
            }

            return $"Calling... {number}";
        }
    }
}
