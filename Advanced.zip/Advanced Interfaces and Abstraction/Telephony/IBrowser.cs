﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
   public interface IBrowser
    {
        string Browse(string site);
    }
}
