﻿using System;

namespace _1._Define_an_Interface_IPerson
{
  public  class Startup
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
