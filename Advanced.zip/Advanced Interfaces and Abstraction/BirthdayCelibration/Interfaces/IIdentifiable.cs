﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelibration.Interfaces
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
