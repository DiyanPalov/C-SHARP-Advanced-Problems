﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BorderControl
{
  public  class Program
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> all = new List<IIdentifiable>();

            string command = Console.ReadLine();

            while (command!="End")
            {
                string[] tokens = command.Split(" ");

                if (tokens.Length==3)
                {
                    string name = tokens[0];
                    int age = int.Parse(tokens[1]);
                    string id = tokens[2];
                    Citizens citizen = new Citizens(name,age,id);

                    all.Add(citizen);
                }
                else if (tokens.Length==2)
                {
                    string model = tokens[0];
                    string id = tokens[1];
                    Robots robot = new Robots(model, id);
                    all.Add(robot);
                }
                command = Console.ReadLine();
            }

            string fakeId = Console.ReadLine();

          // all.Where(c => c.Id.EndsWith(fakeId)).Select(c => c.Id).ToList();

            foreach (var item in all.Where(c => c.Id.EndsWith(fakeId)).Select(c => c.Id).ToList())
            {
                Console.WriteLine(item);
            }
            
        }
    }
}
