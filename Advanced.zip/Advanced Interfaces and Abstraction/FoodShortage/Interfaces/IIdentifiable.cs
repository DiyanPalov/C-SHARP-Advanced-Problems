﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage.Interfaces
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
